package com.example.lineoverlay

import android.graphics.PointF
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

object Geometry {
    /**
     * Returns the direct path (index 0) followed by every bank-shot path with
     * up to [maxBounces] rail hits, using the "unfolded table" mirror method.
     * Each path is start -> bounce points (on the real rails) -> target.
     */
    fun paths(start: PointF, target: PointF, corners: List<PointF>, maxBounces: Int = 1): List<List<PointF>> {
        val direct = listOf(start, target)
        if (corners.size != 4) return listOf(direct)
        val left = corners.minOf { it.x }; val right = corners.maxOf { it.x }
        val top = corners.minOf { it.y }; val bottom = corners.maxOf { it.y }
        val w = right - left; val h = bottom - top
        if (w <= 1f || h <= 1f) return listOf(direct)

        // Pocket centres usually sit just outside the playing surface; unfold using the point on the cushion.
        val tgt = PointF(target.x.coerceIn(left, right), target.y.coerceIn(top, bottom))
        val out = mutableListOf<List<PointF>>(direct)
        for (mx in -maxBounces..maxBounces) for (my in -maxBounces..maxBounces) {
            if (mx == 0 && my == 0) continue
            if (abs(mx) + abs(my) > maxBounces) continue
            val ix = (if (mx % 2 == 0) tgt.x else left + right - tgt.x) + mx * w
            val iy = (if (my % 2 == 0) tgt.y else top + bottom - tgt.y) + my * h
            val qs = crossings(start, ix, iy, left, top, w, h)
            val pts = mutableListOf(start)
            for (q in qs) {
                val ux = start.x + (ix - start.x) * q
                val uy = start.y + (iy - start.y) * q
                pts.add(PointF(fold(ux, left, w), fold(uy, top, h)))
            }
            pts.add(tgt)
            if (tgt.x != target.x || tgt.y != target.y) pts.add(target)
            out.add(pts)
        }
        return out
    }

    /** Kept for compatibility: the direct path only. */
    fun reflectedPath(start: PointF, target: PointF, corners: List<PointF>): List<PointF> =
        paths(start, target, corners, 0)[0]

    // Parameters (0..1) where the unfolded line crosses a tile boundary (= a rail hit).
    private fun crossings(a: PointF, bx: Float, by: Float, l: Float, t: Float, w: Float, h: Float): List<Float> {
        val dx = bx - a.x; val dy = by - a.y
        val qs = mutableListOf<Float>()
        if (abs(dx) > 0.001f) {
            val k0 = ceil((min(a.x, bx) - l) / w).toInt(); val k1 = floor((max(a.x, bx) - l) / w).toInt()
            for (k in k0..k1) { val q = (l + k * w - a.x) / dx; if (q > 1e-4f && q < 1f - 1e-4f) qs.add(q) }
        }
        if (abs(dy) > 0.001f) {
            val k0 = ceil((min(a.y, by) - t) / h).toInt(); val k1 = floor((max(a.y, by) - t) / h).toInt()
            for (k in k0..k1) { val q = (t + k * h - a.y) / dy; if (q > 1e-4f && q < 1f - 1e-4f) qs.add(q) }
        }
        return qs.sorted()
    }

    // Triangle-wave fold of an unfolded coordinate back onto [lo, lo+size].
    private fun fold(v: Float, lo: Float, size: Float): Float {
        var m = (v - lo) % (2f * size)
        if (m < 0f) m += 2f * size
        return lo + if (m > size) 2f * size - m else m
    }
}
