package com.example.lineoverlay

import android.content.Context
import android.graphics.PointF

object Prefs {
    private const val NAME = "guide"
    private const val CALIBRATED = "calibrated"
    private const val CORNERS = "corners"
    private const val POCKETS = "pockets"
    private const val CIRCLE_X = "circle_x"
    private const val CIRCLE_Y = "circle_y"

    fun saveCalibration(context: Context, corners: List<PointF>, pockets: List<PointF>) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putBoolean(CALIBRATED, true).putString(CORNERS, encode(corners))
            .putString(POCKETS, encode(pockets)).apply()
    }
    fun isCalibrated(context: Context) = context.getSharedPreferences(NAME, Context.MODE_PRIVATE).getBoolean(CALIBRATED, false)
    fun corners(context: Context) = decode(context.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString(CORNERS, "") ?: "")
    fun pockets(context: Context) = decode(context.getSharedPreferences(NAME, Context.MODE_PRIVATE).getString(POCKETS, "") ?: "")
    fun saveCircle(context: Context, x: Float, y: Float) = context.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putFloat(CIRCLE_X,x).putFloat(CIRCLE_Y,y).apply()
    fun circle(context: Context): PointF? {
        val p=context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        if(!p.contains(CIRCLE_X)) return null
        return PointF(p.getFloat(CIRCLE_X,0f),p.getFloat(CIRCLE_Y,0f))
    }
    private fun encode(points: List<PointF>) = points.joinToString(";") { "${it.x},${it.y}" }
    private fun decode(s:String):List<PointF> = s.split(";").mapNotNull { a ->
        val p=a.split(",")
        if(p.size==2) p[0].toFloatOrNull()?.let { x -> p[1].toFloatOrNull()?.let { y -> PointF(x,y) } } else null
    }
}
