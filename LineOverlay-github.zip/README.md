# Line Overlay Guide

Android floating overlay for pool games: manual table calibration, a draggable guide circle, a faint straight line to each of the six pockets, and one-rail bank-shot lines.

## Use
1. Install the APK, open the app, grant **Display over other apps**.
2. Tap **Calibrate table**, then tap the four playing-surface corners and the six pocket centers in your game.
3. Drag the guide circle to the cue ball. Tap the floating ◎ button to hide/show the guide; long-press it to recalibrate.

## Build
Push to `main` (or run the workflow manually) and download `line-overlay-apk` from the Actions run.
Requires JDK 17, Gradle 8.9, Android SDK 35.
